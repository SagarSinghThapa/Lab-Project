const express = require("express");
const fs = require("fs");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(express.json());
app.use(cors()); // Allow frontend to communicate

const FILE_PATH = path.join(__dirname, "diabetes_data.csv"); // Store CSV in same folder

// Ensure CSV file exists with headers
if (!fs.existsSync(FILE_PATH)) {
    fs.writeFileSync(FILE_PATH, "Date,Sleep Hours,Morning Sugar,Afternoon Sugar,Evening Sugar\n", "utf8");
}

// Route to save data (appends new data)
app.post("/save-csv", (req, res) => {
    const { csvData } = req.body;

    fs.appendFile(FILE_PATH, csvData, "utf8", (err) => {
        if (err) {
            console.error("Error saving CSV:", err);
            return res.status(500).send("Failed to save CSV");
        }
        res.send("CSV file updated successfully!");
    });
});

// Route to download CSV from the same folder
app.get("/download-csv", (req, res) => {
    if (fs.existsSync(FILE_PATH)) {
        res.download(FILE_PATH, "diabetes_data.csv", (err) => {
            if (err) {
                console.error("Error downloading CSV:", err);
                res.status(500).send("Error downloading file");
            }
        });
    } else {
        res.status(404).send("CSV file not found");
    }
});

// Start the server
app.listen(3000, () => console.log("✅ Server running at http://localhost:3000"));
