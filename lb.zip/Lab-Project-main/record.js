function addRow() {
    let table = document.getElementById("trackerTable").getElementsByTagName('tbody')[0];
    let newRow = table.insertRow();
    
    let dateCell = newRow.insertCell(0);
    let sleepCell = newRow.insertCell(1);
    let morningCell = newRow.insertCell(2);
    let afternoonCell = newRow.insertCell(3);
    let eveningCell = newRow.insertCell(4);
    let actionCell = newRow.insertCell(5);
    
    dateCell.innerHTML = `<input type='date'>`;
    sleepCell.innerHTML = `<input type='number' min='0' max='24' placeholder='Hours'>`;
    morningCell.innerHTML = `<input type='number' placeholder='mg/dL'>`;
    afternoonCell.innerHTML = `<input type='number' placeholder='mg/dL'>`;
    eveningCell.innerHTML = `<input type='number' placeholder='mg/dL'>`;
    actionCell.innerHTML = `<button onclick='deleteRow(this)'>Delete</button>`;
}

function deleteRow(button) {
    let row = button.parentNode.parentNode;
    row.parentNode.removeChild(row);
}

function extractData() {
    let dates = [];
    let morningLevels = [];
    let afternoonLevels = [];
    let eveningLevels = [];

    let table = document.getElementById("trackerTable").getElementsByTagName('tbody')[0];
    let rows = table.getElementsByTagName('tr');

    for (let row of rows) {
        let cells = row.getElementsByTagName('td');
        if (cells.length > 0) {
            let dateInput = cells[0].querySelector('input');
            let morningInput = cells[2].querySelector('input');
            let afternoonInput = cells[3].querySelector('input');
            let eveningInput = cells[4].querySelector('input');

            dates.push(dateInput ? dateInput.value : "");
            morningLevels.push(morningInput && morningInput.value.trim() ? parseInt(morningInput.value.trim()) : 0);
            afternoonLevels.push(afternoonInput && afternoonInput.value.trim() ? parseInt(afternoonInput.value.trim()) : 0);
            eveningLevels.push(eveningInput && eveningInput.value.trim() ? parseInt(eveningInput.value.trim()) : 0);
        }
    }
    
    return { dates, morningLevels, afternoonLevels, eveningLevels };
}

// Function to collect table data and send to server
function saveCSVToServer() {
    let table = document.getElementById("trackerTable");
    let rows = table.querySelectorAll("tr");

    let csvData = "";

    rows.forEach(row => {
        let cols = row.querySelectorAll("th, td");
        let rowData = [];

        cols.forEach(col => {
            let input = col.querySelector("input");
            rowData.push(input ? input.value : col.innerText);
        });

        csvData += rowData.join(",") + "\n";
    });

    fetch("http://localhost:3000/save-csv", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ csvData })
    })
    .then(response => response.text())
    .then(message => alert(message))
    .catch(error => console.error("Error:", error));
}

// Function to download the CSV file from server
function downloadCSV() {
    window.location.href = "http://localhost:3000/download-csv";
}
