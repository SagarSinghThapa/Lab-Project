import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from scipy.stats import pearsonr
from scipy.stats import f_oneway
from scipy.stats import shapiro

# Load dataset
data = pd.read_csv('diabetes_data.csv')

# Calculate Mean Sugar Level
data["Mean Sugar Level"] = data[["Morning Sugar Level", "Afternoon Sugar Level", "Evening Sugar Level"]].mean(axis=1)

# Define Independent (X) and Dependent (Y) variables
X = data[["Sleep Hours"]]  # Independent variable (Feature)
Y = data["Mean Sugar Level"]  # Dependent variable (Target)

# Split into training & testing datasets
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=42)

# Train the Linear Regression Model
model = LinearRegression()
model.fit(X_train, y_train)

low_sleep = data[data["Sleep Hours"] < 6]["Mean Sugar Level"]
medium_sleep = data[(data["Sleep Hours"] >= 6) & (data["Sleep Hours"] < 8)]["Mean Sugar Level"]
high_sleep = data[data["Sleep Hours"] >= 8]["Mean Sugar Level"]
f_stat, p_value = f_oneway(low_sleep, medium_sleep, high_sleep)

# Print results
print(f"F-Statistic: {f_stat:.4f}")
print(f"P-Value: {p_value:.4f}")

# Interpretation
if p_value < 0.05:
    print("Result: Sleep hours have a statistically significant effect on sugar levels.")
else:
    print("Result: No significant effect of sleep hours on sugar levels.")
plt.figure(figsize=(8, 5))
sns.boxplot(x=pd.cut(data["Sleep Hours"], bins=[0, 6, 8, 10], labels=["Low", "Medium", "High"]),
            y=data["Mean Sugar Level"])
plt.xlabel("Sleep Hours Category")
plt.ylabel("Mean Sugar Level")
plt.title("Distribution of Mean Sugar Level by Sleep Hours")
plt.show()

print("Shapiro-Wilk Test for Normality:")
for group_name, group_data in [("Low Sleep", low_sleep), ("Medium Sleep", medium_sleep), ("High Sleep", high_sleep)]:
    stat, p = shapiro(group_data)
    print(f"{group_name}: W={stat:.4f}, p={p:.4f}")